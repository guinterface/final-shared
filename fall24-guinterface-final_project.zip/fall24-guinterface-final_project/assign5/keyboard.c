/* File: keyboard.c
 * The keyboard file process the information from the ps2 and makes the adjusted char available to the shell. 
 * This includes configuration of especial commands. 
 * -----------------
 */
#include "keyboard.h"
#include "ps2.h"
#include "printf.h"

static ps2_device_t *dev;

void keyboard_init(gpio_id_t clock_gpio, gpio_id_t data_gpio) {
    dev = ps2_new(clock_gpio, data_gpio);
}

uint8_t keyboard_read_scancode(void) {
    return ps2_read(dev);
}
key_action_t keyboard_read_sequence(void) {
    int event = 0; 
    uint8_t read = keyboard_read_scancode();
    if (read == 0xe0) {
        read = keyboard_read_scancode();
    }

    if (read == 0xf0) {
        event = 1;
        read = keyboard_read_scancode();
    }
    key_action_t action = {event ? KEY_RELEASE : KEY_PRESS, read}; 
    return action;
}
int caps_lock_parity = 0;
int alt_parity = 0;
int shift_parity = 0;
int ctrl_parity = 0;

key_event_t keyboard_read_event(void) {
    keyboard_modifiers_t modifiers = 0;
    key_action_t action;
    ps2_key_t key;
    
    while (1) {

        action = keyboard_read_sequence();
        uint8_t keycode = action.keycode;
        key = ps2_keys[keycode];

        if(key.ch == PS2_KEY_SHIFT || key.ch == PS2_KEY_ALT || key.ch == PS2_KEY_CTRL || key.ch == PS2_KEY_CAPS_LOCK){
        
        // Handle key press/release and modify modifiers
        
        if (key.ch == PS2_KEY_SHIFT) {
            if (action.what == KEY_PRESS) {
                shift_parity = 1;
            } else if (action.what == KEY_RELEASE) {
                shift_parity = 0;
            }
        }
        
        if (key.ch == PS2_KEY_ALT) {
            if (action.what == KEY_PRESS) {
                alt_parity = 1;
            } else if (action.what == KEY_RELEASE) {
                alt_parity = 0;
            }
        }
        
        if (key.ch == PS2_KEY_CTRL) {
            if (action.what == KEY_PRESS) {
                ctrl_parity = 1;
            } else if (action.what == KEY_RELEASE) {
                ctrl_parity = 0;
            }
        }
         if (key.ch == PS2_KEY_CAPS_LOCK && action.what == KEY_PRESS){
          caps_lock_parity ^=1;
        }
        }else{

        
        if (caps_lock_parity == 1) {
            modifiers |= KEYBOARD_MOD_CAPS_LOCK;
        } else {
            modifiers &= ~KEYBOARD_MOD_CAPS_LOCK;
        }

        if (shift_parity == 1) {
            modifiers |= KEYBOARD_MOD_SHIFT;
        } else {
            modifiers &= ~KEYBOARD_MOD_SHIFT;
        }

        if (alt_parity == 1) {
            modifiers |= KEYBOARD_MOD_ALT;
        } else {
            modifiers &= ~KEYBOARD_MOD_ALT;
        }

        if (ctrl_parity == 1) {
            modifiers |= KEYBOARD_MOD_CTRL;
        } else {
            modifiers &= ~KEYBOARD_MOD_CTRL;
        }
        

        // Exit loop and return the key event with modifiers
        break;
        }
      }
    
    key_event_t event = {action, key, modifiers};
    return event;
}



char keyboard_read_next(void) {
    while(1){
    key_event_t event = keyboard_read_event(); 
    key_action_t action = event.action;
    ps2_key_t key = event.key;
    keyboard_modifiers_t modifiers = event.modifiers;
    if(action.what == KEY_PRESS){
      if(modifiers>>0 & 1){
        return key.other_ch;
        } 
      if(key.ch >= 'a' && key.ch <= 'z'){
        if(modifiers>>3 & 1){
        return key.other_ch; 
        }
      }
      return key.ch; 
    }
  }
}
