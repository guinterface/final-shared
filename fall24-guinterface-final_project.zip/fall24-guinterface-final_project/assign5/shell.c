/* File: shell.c
 * -------------
 *  Program for configuring shell with the keyboard inputs and the configured commands
 */
#include "shell.h"
#include "shell_commands.h"
#include "uart.h"
#include "malloc.h"
#include "ps2.h"
#include "keyboard.h"
#include "printf.h"
#include "strings.h"
#include "mango.h"
#define LINE_LEN 80

// Module-level global variables for shell
static struct {
    input_fn_t shell_read;
    formatted_fn_t shell_printf;
} module;


// NOTE TO STUDENTS:
// Your shell commands output various information and respond to user
// error with helpful messages. The specific wording and format of
// these messages would not generally be of great importance, but
// in order to streamline grading, we ask that you aim to match the
// output of the reference version.
//
// The behavior of the shell commands is documented in "shell_commands.h"
// https://cs107e.github.io/header#shell_commands
// The header file gives example output and error messages for all
// commands of the reference shell. Please match this wording and format.
//
// Your graders thank you in advance for taking this care!
const int num_commands = 6;

static const command_t commands[] = {
    {"help",  "help [cmd]",  "print command usage and description", cmd_help},
    {"echo",  "echo [args]", "print arguments", cmd_echo},
    {"clear", "clear",       "clear screen (if your terminal supports it)", cmd_clear},
    {"reboot", "reboot", "reboot the Mango Pi", cmd_reboot},
    {"peek", "peek [addr]", "print contents of memory at address", cmd_peek},
    {"poke", "poke [addr] [val]", "store value into memory at address", cmd_poke}
};

int cmd_echo(int argc, const char *argv[]) {
    for (int i = 0; i < argc; ++i)
        module.shell_printf("%s ", argv[i]);
    module.shell_printf("\n");
    return 0;
}

int cmd_help(int argc, const char *argv[]) {
    if(argc ==0){
      for(int i = 0; i< num_commands; i++){

        module.shell_printf("%s ", commands[i].usage);
        module.shell_printf("      %s \n", commands[i].description);
      }
      return 0; 
    }else{
      for(int i = 0; i< num_commands; i++){
        if(strcmp(commands[i].name, argv[0]) == 0){
          module.shell_printf("%s ", commands[i].usage);
          module.shell_printf("      %s \n", commands[i].description);
          return 0; 
        }
      }
    }
    module.shell_printf("error: no such command '%s'\n", argv[0]);
    return -1;
}

int cmd_reboot(int argc, const char *argv[]){
  module.shell_printf("Rebooting..."); 
  mango_reboot();
  return 0;
}

int cmd_clear(int argc, const char* argv[]) {
    module.shell_printf("\f");   // formfeed character
    return 0;
}

int cmd_peek(int argc, const char *argv[]) {
  if (argc == 0) {
    module.shell_printf("error: peek expects 1 argument [addr]\n");
    return -1;
  } else {
    uintptr_t addr = (uintptr_t)strtonum(argv[0], NULL);
    if (addr == 0) {
      module.shell_printf("error: peek cannot convert '%s'\n", argv[0]);
      return -1;
    }
   volatile uint32_t *pointer = (volatile uint32_t *)addr;
    uint32_t result = *pointer; 
    
    if ((uintptr_t)pointer % 4 != 0) {
      module.shell_printf("error: peek address must be 4-byte aligned.\n");
      return -1;
    }
    
    module.shell_printf("%s : %x\n", argv[0], result);
    return 0;
  }
  return -1;
}


int cmd_poke(int argc, const char *argv[]) {
    if (argc <=1) {
      module.shell_printf("error: poke expects 2 argument [addr] and [val]\n");  
      return -1;

    } else {
      if((strtonum(argv[1], NULL) != 0) || (strcmp(argv[1], "0") == 0)) {
       if(strtonum(argv[0], NULL) != 0) {
        uint32_t *pointer = (uint32_t *)strtonum(argv[0], NULL);
        int value = (int) strtonum(argv[1], NULL); 
        
        if((uintptr_t)pointer%4==0){
          *pointer = value;
          return 0;
        }else{
          module.shell_printf("error: peek address must be 4-byte aligned.\n"); 
          return -1;
        }
    }else{
    module.shell_printf("error: peek cannot convert '%s'\n", argv[0]);
    }
      }else{
        module.shell_printf("error: peek cannot convert '%s'\n", argv[1]);
      }
    return -1;
  }
}


void shell_init(input_fn_t read_fn, formatted_fn_t print_fn) {
    module.shell_read = read_fn;
    module.shell_printf = print_fn;
}

void shell_bell(void) {
    uart_putchar('\a');
}
static char *strndup(const char *src, size_t n) {
    char *dst = (char*) malloc(2*(n+1) * sizeof(char));
    memcpy(dst, src, n);
    dst[n] = '\0';
   // printf("size: %d \n", (int) n);
   // printf("after memcpy: %s \n", dst); 
    return dst;
}

static bool isspace(char ch) {
    return ch == ' ' || ch == '\t' || ch == '\n';
}
//Tokenize function to separate string
static int tokenize(const char *line, char *array[], int max) {
    int ntokens = 0;
    const char *cur = line;

    while (ntokens < max) {
        while (isspace(*cur)) cur++;    // skip spaces (stop non-space/null)
        if (*cur == '\0') break;        // no more non-space chars
        const char *start = cur;
        while (*cur != '\0' && !isspace(*cur)) cur++; // advance to end (stop space/null)
        array[ntokens++] = strndup(start, cur - start);   // make heap-copy, add to array
    }
    return ntokens;
}

//read_line to add input to shell
void shell_readline(char buf[], size_t bufsize) {
  int i = 0;
  int max = 0;
  while (i < bufsize-1) { 
    char cur = module.shell_read();
    int caps_lock_parity = 0;

    if (cur == PS2_KEY_ARROW_RIGHT) {
      if (i < max - 1) {
        module.shell_printf("%c", buf[i]);
        i++;
      }
    }
    else if (cur ==PS2_KEY_ARROW_LEFT) {
      if (i > 0) {
        module.shell_printf("%c", '\b');
        i--;
      }
    }
    else if (cur <= 0x7f) {  // Only process other characters if it's <= 0x7f
      if (cur == '\b') {
        if (i >= 1) {
          i--;
          buf[i] = '\0';
          module.shell_printf("%c", '\b');
          module.shell_printf("%c", ' ');
          module.shell_printf("%c", '\b');
          max--;
        } else {
          shell_bell();
        }
      } else {
        if (cur == '\n') {
          module.shell_printf("%c", '\n');
          buf[i] = '\0';
          return;
        } else {
          module.shell_printf("%c", cur);
          buf[i] = cur;
          i++;
          max++;
        }
      }
    }
  }
  buf[bufsize-1] = '\0'; 
  shell_bell();
}


int shell_evaluate(const char *line) {
    char *array[LINE_LEN]; 
    int max = LINE_LEN; 
    int ntokens = tokenize(line, array, max); 
    if(ntokens == 0){
      return -1; 
    }
    for(int i = 0; i < num_commands; i++){
    if(strcmp(array[0], commands[i].name) == 0){
      return commands[i].fn(ntokens-1, (const char **) array+1);

    }
  } 

    return -1;
}

void shell_run(void) {
    module.shell_printf("Welcome to the CS107E shell.\nRemember to type on your PS/2 keyboard!\n");
    while (1) {
        char line[LINE_LEN];

        module.shell_printf("Pi> ");
        shell_readline(line, sizeof(line));
        shell_evaluate(line);
    }
}



