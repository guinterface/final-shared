/* File: malloc.c
 * --------------
 * ***** TODO: add your file header comment here *****
 */


 /*
 * The code given below is simple "bump" allocator from lecture.
 * An allocation request is serviced by using sbrk to extend
 * the heap segment.
 * It does not recycle memory (free is a no-op) so when all the
 * space set aside for the heap is consumed, it will not be able
 * to service any further requests.
 *
 * This code is given here just to show the very simplest of
 * approaches to dynamic allocation. You will replace this code
 * with your own heap allocator implementation.
 */

#include "malloc.h"
#include "memmap.h"
#include "printf.h"
#include <stddef.h> // for NULL
#include "strings.h"

/*
 * Data variables private to this module used to track
 * statistics for debugging/validate heap:
 *    count_allocs, count_frees, total_bytes_requested
 */
static int count_allocs, count_frees, total_bytes_requested;
void* heap_end;  
/*
 * The segment of memory available for the heap runs from &__heap_start
 * to &__heap_max (symbols from memmap.ld establish these boundaries)
 *
 * The variable cur_head_end is initialized to &__heap_start and this
 * address is adjusted upward as in-use portion of heap segment
 * enlarges. Because cur_head_end is qualified as static, this variable
 * is not stored in stack frame, instead variable is located in data segment.
 * The one variable is shared by all and retains its value between calls.
 */

// Call sbrk to enlarge in-use heap area
void *sbrk(size_t nbytes) {
    // __heap_start, __heap_max symbols are defined in linker script memmap.ld
    static void *cur_heap_end =  &__heap_start;     // IMPORTANT: static

    void *new_heap_end = (char *)cur_heap_end + nbytes;
    if (new_heap_end > (void *)&__heap_max)    // if request would extend beyond heap max
        return NULL;                // reject
    void *prev_heap_end = cur_heap_end;
    cur_heap_end = new_heap_end;
    heap_end = cur_heap_end; 
    return prev_heap_end;
}

// Simple macro to round up x to multiple of n.
// The efficient but tricky bitwise approach it uses
// works only if n is a power of two -- why?
#define roundup(x,n) (((x)+((n)-1))&(~((n)-1)))

void *malloc(size_t nbytes) {
    count_allocs++;
    nbytes = roundup(nbytes, 8);
    total_bytes_requested += nbytes + 8;

    void *current = &__heap_start;
    //Continue until we find an available block
    while (1) {
      //stop if we are over the current limit
        if (current >= (void *)heap_end) {
            break;
        }
        
        int size = *(int *)current;
        int active = *((int *)current + 1);
        //Create a new block with the remaining available size
        if (active == 0 && size >= nbytes) {
          int occupied = 0; 
            if (size > nbytes + 8) {
                void *new_block = (char *)current + nbytes + 8;
                *(int *)new_block = size - nbytes - 8;
                *((int *)new_block + 1) = 0;
                occupied = size - nbytes;
            }
            //Fill the block with the data from function call
            *(int *)current = size-occupied;
            *((int *)current + 1) = 1;
            return (char *)current + 8;
        }
        //Update to next block
        current = (char *)current + size + 8;
    }
    //If we could not find an open space, expand the limit
    void *beginning = sbrk(nbytes + 8);
    if (beginning == NULL) {
        return beginning;
    }
    *(int *)beginning = nbytes;
    *((int *)beginning + 1) = 1;
    return (char *)beginning + 8;
}

void free(void *ptr) {
    count_frees++;

    if (ptr == NULL || ptr < (void *)&__heap_start || ptr >= (void *)heap_end) {
        return; 
    }

    void *current = (char *)ptr - 8;
    int size = *((int *)current);
    int active = *((int *)current + 1);
    //incorrect message
    if (active == 0) {
        return; 
    }
    //Free data
    *((int *)current + 1) = 0;
    //Check next blocks
    void *forward_block = (char *)current + size + 8;
    while (forward_block < (void *)heap_end) {
        int next_size = *((int *)forward_block);
        int next_active = *((int *)forward_block + 1);
         //Coalesce blocks
        if (next_active == 0) {
            size += next_size + 8;
            *((int *)current) = size;
            forward_block = (char *)forward_block + next_size + 8;
        } else {
            break;
        }
    }
}




void heap_dump(const char *label) {
    printf("\n---------- HEAP DUMP (%s) ----------\n", label);
    printf("Heap segment at %p - %p\n", &__heap_start, sbrk(0));

    void *current = &__heap_start;

    while (1) {
        if (current >= (void *)heap_end) {
            break;
        }

        int size = *(int *)current;
        int active = *((int *)current + 1); // Adjusted to the correct offset

        
        current = (char *)current + size + 8; // Move to the next block (size + header)
    }

    printf("----------  END DUMP (%s) ----------\n", label);
    printf("Stats: %d in-use (%d allocs, %d frees), %d total bytes requested\n\n",
           count_allocs - count_frees, count_allocs, count_frees, total_bytes_requested);
}


void malloc_report (void) {
    printf("\n=============================================\n");
    printf(  "         Mini-Valgrind Malloc Report         \n");
    printf(  "=============================================\n");
    /***** TODO EXTENSION: Your code goes here if implementing extension *****/
}

void report_damaged_redzone (void *ptr) {
    printf("\n=============================================\n");
    printf(  " **********  Mini-Valgrind Alert  ********** \n");
    printf(  "=============================================\n");
    printf("Attempt to free address %p that has damaged red zone(s):", ptr);
    /***** TODO EXTENSION: Your code goes here if implementing extension *****/
}
