/* File: backtrace.c
 * -----------------
 * ***** TODO: add your file header comment here *****
 */
#include "backtrace.h"
#include "mango.h"
#include "printf.h"
#include "symtab.h"

// helper function implemented in file backtrace_asm.s
extern unsigned long backtrace_get_fp(void);

int backtrace_gather_frames(frame_t f[], int max_frames) {
    int count = 0;
    void **fp; 
    void **ra;
    fp = (void**) backtrace_get_fp();
    //printf("Cur fp: %8lx  \n", (unsigned long) fp ); 
    //Only deal with available space
    while(fp && count < max_frames){ 
        if ((uintptr_t)fp % sizeof(int) != 0) {
        break;
    }
      //Get saved fp address from offset
      fp = (void **)((int *)fp - 4);
  //    printf("Cur fp: %8lx  \n", (unsigned long) fp );
      //Now get saved ra address from offset
      ra = (void **)((int *)fp +2); 
      //Find the function pointed by ra
      ra = (void **)*ra;
      //Find the previous fp saved address
      fp = (void **)*fp;
      if(!ra){
       // printf("ERROR! RA"); 
        break; 
      }
      frame_t frame; 
      frame.resume_addr  = (unsigned long) ra;
    //   printf("FP: %p, RA: %p\n", fp, ra);
//      printf("Cur ra: %8lx  \n", (unsigned long) ra ); 
      f[count] = frame;
      count++; 

    }
    return count;
}

void backtrace_print_frames(frame_t f[], int n) {
    char labelbuf[128];

    for (int i = 0; i < n; i++) {
        symtab_label_for_addr(labelbuf, sizeof(labelbuf), f[i].resume_addr);
        printf("#%d 0x%08lx at %s\n", i, f[i].resume_addr, labelbuf);
    }
}

void backtrace_print(void) {
    int max = 50;
    frame_t arr[max];

    int n = backtrace_gather_frames(arr, max);
    backtrace_print_frames(arr+1, n-1);   // print frames starting at this function's caller
}


long __stack_chk_guard = 0xEADBEEFDEADBEEFF;

void __stack_chk_fail(void)  {
    frame_t f[10];
    backtrace_gather_frames(f, 10); 
    // backtrace_print_frames(f, 10);
    char labelbuf[128];
     symtab_label_for_addr(labelbuf, sizeof(labelbuf), f[1].resume_addr);
    printf("Stack smashing detected 0x%08lx at %s\n", f[1].resume_addr, labelbuf);
    mango_abort();
}
