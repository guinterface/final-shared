Include information for grader about your assign1 here

-----------
I thought it was more logical to increment both PB_DAT and PB_CFG0 on each loop,
there was a clear iterative logic behind both. Therefore, the code idea differed
slightly from the examples we saw in class but the functionality should be the same

