# Project Name  
**Bat Signal - Reversed**  

## Description of Project Goals  
This project aims to design and build a small quadcopter capable of projecting images onto the ground. The key focus is developing a consistent and reliable flight system. This will involve integrating a flight controller board with sensors and motors through Electronic Speed Controllers (ESCs). The projection mechanism will utilize the physical principles of a camera obscura, with the system controlling the activation of LEDs to facilitate the projection process.  

---

## Objectives  

### Learning Goals  
- Develop a deeper understanding of serial communication and signal processing.  
- Gain practical experience in working with multiple physical variables simultaneously.  

### Core Features  
1. **Flight System:**  
   Establish a reliable quadcopter platform using ESCs to control motor speeds via Pulse Width Modulation (PWM) signals.  
2. **Projection Mechanism:**  
   Implement a camera-obscura-inspired image projection system controlled by precise activation of LEDs.  
3. **Sensor Integration:**  
   Utilize sensors such as a gyroscope and accelerometer (MPU6050) for stability and flight control.  

### Technical Challenges  
- Interfacing ESCs with the flight controller via PWM, ensuring compatibility with I2C pins using a PCA9685 signal translator.  
- Managing sensor data transmission and processing, with a particular focus on gyroscopic and accelerometric inputs.  

---

## Stretch and Backup Goals  

- **Stretch Goal:** Achieve seamless flight stability and dynamic image projection simultaneously.  
- **Backup Goal:** If flight system development proves unfeasible within the deadline, adapt the project to a ground-based vehicle. This alternative would involve modifying the quadcopter design into a car projector, retaining the same motor system while eliminating the complexities of flight stabilization.  

---

## Resources Needed and Budget  

### Components and Sources  
- **Frame:** 3D printed (self-made).  
- **ESC (Electronic Speed Controllers):** Self-purchased.  
- **Propellers:** Self-purchased.  
- **Motors:** Self-purchased.  
- **MPU6050 Sensor:** Purchased.  
- **1S 360mAh LiPo Battery:** Ordered.  
- **PCA9685 (Signal Converter):** Purchased.  
- **Power Distribution Board:** Ordered.  

---

## Team Members and Responsibilities  

### Guilherme  
- Connecting and managing the ESC system (coding).  
- Setting up motors and ESCs (electronics).  

### Carlos Henrique  
- Reading and manipulating sensor data and signals (coding).  
- Designing and 3D printing the frame (software and hardware).  
- Power distribution setup.  

---

## Schedule  

### Week 10: Decomposition and Task Timeline  

#### Monday  
- Begin 3D printing the frame.  
- Make initial connections between components (basic wiring).  

#### Wednesday  
- First implementation of integrated components.  
- Begin programming data transmission and reception.  

#### Thursday  
- Continue programming, focusing on I2C to PWM signal transmission.  

#### Friday  
- Address errors found during testing.  
- Conduct first flight tests.  

#### Saturday  
- Refine parameters based on test results.  
- Continue testing for stability and reliability.  

### Finals Week  
- Progress during finals week will depend on outcomes of the weekend testing phase.  
- Adjust and refine project goals based on progress and identified challenges.  
