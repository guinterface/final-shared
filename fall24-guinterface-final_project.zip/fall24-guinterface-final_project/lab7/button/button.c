
#include "gl.h"
#include "gpio.h"
#include "gpio_extra.h"
#include "gpio_interrupt.h"
#include "interrupts.h"
#include "printf.h"
#include "ringbuffer.h"
#include "uart.h"

static const gpio_id_t BUTTON = GPIO_PB4;
static int gCount = 0;

void wait_for_click(void) {
    // TODO: implement this function to
    // wait for falling edge on button
    // then increment gCount and uart_putstring("click")
    while(gpio_read(BUTTON)!=1){}
    while(gpio_read(BUTTON)!=0){}
    gCount++;
    uart_putstring("click!"); 
}

void redraw(int nclicks) {
    static int nredraw = -1;
    // count number of redraws, alternate bg color on each redraw
    color_t bg = nredraw++ % 2 ? GL_AMBER : GL_BLUE;

    gl_clear(GL_BLACK);
    char buf[100];
    snprintf(buf, sizeof(buf), "Click count = %d (redraw #%d)", nclicks, nredraw);
    gl_draw_string(0, 0, buf, GL_WHITE);
    // intentionally slow loop for educational purposes :-)
    for (int y = gl_get_char_height(); y < gl_get_height(); y++) {
        for (int x = 0; x < gl_get_width(); x++) {
            gl_draw_pixel(x, y, bg);
        }
    }
}
void click_handler(rb_t *aux_data) {
  gCount ++; 
  rb_enqueue(aux_data, gCount);
  uart_putstring((char*)aux_data);
  gpio_interrupt_clear(BUTTON); 
}
void config_button(rb_t *aux_data) {
   interrupts_init(); 
   gpio_interrupt_init();

   gpio_interrupt_enable(BUTTON); 
   gpio_set_input(BUTTON);
   
   gpio_set_pullup(BUTTON); // use internal pullup resistor
    gpio_interrupt_config(BUTTON, GPIO_INTERRUPT_NEGATIVE_EDGE, 1); 
    gpio_interrupt_register_handler(BUTTON, click_handler, aux_data);
    interrupts_global_enable();
}

void main(void) {
    rb_t *rb = rb_new();
    gpio_init();
    uart_init();
    gl_init(800, 600, GL_SINGLEBUFFER);
    config_button(rb);

    int drawn = 0;
    redraw(drawn);
    int ver = gCount; 
    while (true) {
    //    wait_for_click();
        drawn = gCount;
       // if(ver!=gCount){
       
        ver = gCount;
        int *val; 
        while(rb_dequeue(rb, val)){ 
        redraw(drawn);
        }
     // }
    }
}
