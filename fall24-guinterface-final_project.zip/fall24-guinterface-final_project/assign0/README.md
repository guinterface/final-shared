
Guilherme Simioni Bonfim [He/Him]
--------------------------------
Curitiba, Brazil
 || Sophmore, Computer Science

![Alt text](cs107e-image.jpeg)
