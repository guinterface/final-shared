/* File: clock.c
 * -------------
 * ***** Implemented the clok functions for the differnt tasks in the assignment *****
 */
#include "gpio.h"
#include "timer.h"
#include <stdint.h>

void print_number(char number) {
    gpio_id_t segment[7] = {GPIO_PD17, GPIO_PB6, GPIO_PB12, GPIO_PB11, GPIO_PB10, GPIO_PE17, GPIO_PD11};
    gpio_id_t digit[4] = {GPIO_PB4, GPIO_PB3, GPIO_PB2, GPIO_PC0};

    gpio_id_t button = GPIO_PG13;

    // Configure segments
    for (int i = 0; i < 7; i++) {
        gpio_set_output(segment[i]);
    }
    // Configure digit
    gpio_set_output(digit[3]);
    gpio_set_output(digit[2]);
    gpio_set_output(digit[1]);
    gpio_set_output(digit[0]);
    // Configure button
    gpio_set_input(button);
    
    // Turn on digits
    gpio_write(digit[3], 1);
    gpio_write(digit[2], 1);
    gpio_write(digit[1], 1);
    gpio_write(digit[0], 1);

    // Write numbers in clock
    for (int j = 0; j < 7; j++) {
        gpio_write(segment[j],(number>>j)& 1); // get the corresponding bit
        timer_delay_ms(200);
    }
}

void refresh_loop(char number1, char number2, char number3, char number4){
gpio_id_t segment[7] = {GPIO_PD17, GPIO_PB6, GPIO_PB12, GPIO_PB11, GPIO_PB10, GPIO_PE17, GPIO_PD11};
gpio_id_t digit[4] = {GPIO_PB4, GPIO_PB3, GPIO_PB2, GPIO_PC0};

gpio_id_t button = GPIO_PG13;

// Create a list of the numbers to make iterations easier
char numbers[4] = {number1, number2, number3, number4};
// Configure segments
for (int i = 0; i < 7; i++) {
    gpio_set_output(segment[i]);
}

// Configure button
gpio_set_input(button);

// Turn on all digits
for(int i = 0; i < 4; i ++){
    gpio_set_output(digit[i]);
  }

unsigned long init_time = timer_get_ticks(); // get initial time
while(timer_get_ticks()-init_time<27000000){
for(int i = 0; i < 4; i ++){
  gpio_write(digit[i], 1);  //make the current digit active
  
for (int j = 0; j < 7; j++) {
    gpio_write(segment[j], (numbers[i]>>j)& 1 ); // turn on only the corresponding segments
    timer_delay_us(850); // await
    }
for (int j = 0; j < 7; j++) {
       gpio_write(segment[j],0); // turn off everything to avoid interference between segments
      }
gpio_write(digit[i], 0); //change the current active digit 
  }
 }
}
void clock(int min, int sec){
// Configure button and numbers
  gpio_id_t button = GPIO_PG13;
  gpio_set_input(button); // configure button as input
  char numbers[10] = {
           0b0111111, 0b00000110, 0b01011011, 0b01001111,
          0b01100110, 0b01101101, 0b01111101, 0b00000111,
          0b01111111, 0b01100111
      };
  while(true){
// Continue checking until button is clicked
  if (gpio_read(button) == 0){
  while(min != 0 || sec != 0){
// Display current time
    refresh_loop(numbers[min/10], numbers[min%10], numbers[sec/10], numbers[sec%10]); 
// Update time
    if(sec==0){min = min-1; sec = 59;}else{sec = sec-1;}
     }
   }
  }
}

void main(void) {
    char numbers[10] = {
        0b0111111, 0b00000110, 0b01011011, 0b01001111,
        0b01100110, 0b01101101, 0b01111101, 0b00000111,
        0b01111111, 0b01100111
    };

    // Loop through numbers and print each one
   // for (int i = 0; i < 10; i++) {
     //   print_number(numbers[i]);
   // }
// refresh_loop(numbers[1], numbers[3], numbers[6], numbers[7]);
 clock(1,7); 
}
