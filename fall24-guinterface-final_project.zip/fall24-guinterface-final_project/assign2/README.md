Include information for grader about your assign2 here

 --------------- // ------------------

 I unfortunately used 2 jumpers in my hardware, since I believe the connections I had made in lab were not long enough (therefore I could not
         write on certain pins), but those were the exception

 For some reason, in my clock the first digit is much less visible than the others - although the change in numbers is still visible. I believe this is probably due to the hardware connections, too, so there should be no software implications.
