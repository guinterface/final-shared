/* File: gpio.c
 * ------------
 * ***** TODO: add your file header comment here *****
 */
#include "gpio.h"
#include <stddef.h>
#include "printf.h"

enum { GROUP_B = 0, GROUP_C, GROUP_D, GROUP_E, GROUP_F, GROUP_G };

typedef struct  {
    unsigned int group;
    unsigned int pin_index;
} gpio_pin_t;

// The gpio_id_t enumeration assigns a symbolic constant for each
// in such a way to use a single hex constant. The more significant
// hex digit identifies the group and lower 2 hex digits are pin index:
//       constant 0xNnn  N = which group,  nn = pin index within group
//
// This helper function extracts the group and pin index from a gpio_id_t
// e.g. GPIO_PB4 belongs to GROUP_B and has pin_index 4
static gpio_pin_t get_group_and_index(gpio_id_t gpio) {
    gpio_pin_t gp;
    gp.group = gpio >> 8;
    gp.pin_index = gpio & 0xff; // lower 2 hex digits
    return gp;
}

// The gpio groups are differently sized, e.g. B has 13 pins, C only 8.
// This helper function confirms that a gpio_id_t is valid (group
// and pin index are valid)
bool gpio_id_is_valid(gpio_id_t pin) {
    gpio_pin_t gp = get_group_and_index(pin);
    switch (gp.group) {
        case GROUP_B: return (gp.pin_index <= GPIO_PB_LAST_INDEX);
        case GROUP_C: return (gp.pin_index <= GPIO_PC_LAST_INDEX);
        case GROUP_D: return (gp.pin_index <= GPIO_PD_LAST_INDEX);
        case GROUP_E: return (gp.pin_index <= GPIO_PE_LAST_INDEX);
        case GROUP_F: return (gp.pin_index <= GPIO_PF_LAST_INDEX);
        case GROUP_G: return (gp.pin_index <= GPIO_PG_LAST_INDEX);
        default:      return false;
    }
}

// This helper function is suggested to return the address of
// the config0 register for a gpio group, i.e. get_cfg0_reg(GROUP_B)
// Refer to the D1 user manual to learn the address the config0 register
// for each group. Be sure to note how the address of the config1 and
// config2 register can be computed as relative offset from config0.


// I had written this function before reading the description for the already 
// given helper function, and therefore kept with the different name
 static volatile unsigned int *get_cfg(int group) {
    switch (group) {
        case GROUP_B: return (unsigned int *)(0x2000030);
        case GROUP_C: return (unsigned int *)(0x2000060);
        case GROUP_D: return (unsigned int *)(0x2000090);
        case GROUP_E: return (unsigned int *)(0x20000c0);
        case GROUP_F: return (unsigned int *)(0x20000f0);
        case GROUP_G: return (unsigned int *)(0x2000120);
        default:      return (unsigned int *)0x0;
    }
}



// This helper function is suggested to return the address of
// the data register for a gpio group. Refer to the D1 user manual
// to learn the address of the data register for each group.
//
static volatile unsigned int *get_data_reg(unsigned int group) {
    switch (group) {
        case GROUP_B: return (unsigned int *)(0x2000040);
        case GROUP_C: return (unsigned int *)(0x2000070);
        case GROUP_D: return (unsigned int *)(0x20000a0);
        case GROUP_E: return (unsigned int *)(0x20000d0);
        case GROUP_F: return (unsigned int *)(0x2000100);
        case GROUP_G: return (unsigned int *)(0x2000130);
        default:      return (unsigned int *)0x0;
    }
}

void gpio_init(void) {
    // no initialization required for this peripheral
}

void gpio_set_input(gpio_id_t pin) {
    gpio_set_function(pin, GPIO_FN_INPUT);
}

void gpio_set_output(gpio_id_t pin) {
    gpio_set_function(pin, GPIO_FN_OUTPUT);
}


void gpio_set_function(gpio_id_t pin, unsigned int function) {
    if(gpio_id_is_valid(pin) && ((0 <= function && function <=8) || (14 <= function && function <= 15))){ // only use valid pins

    gpio_pin_t gp = get_group_and_index(pin);
    volatile unsigned int *cfg_base = get_cfg(gp.group);
    volatile unsigned int *CFG;

    // Adjust cfg_base based on the pin index to get the correct configuration location
    if (gp.pin_index >= 0 && gp.pin_index < 8) {
        CFG = cfg_base;
    } else if (gp.pin_index >= 8 && gp.pin_index < 16) {
        CFG = cfg_base+1;
    } else if (gp.pin_index >= 16 && gp.pin_index < 24) {
        CFG = cfg_base+2;
    } else {
        return; // early return if pin index is out of range
    }
    
    volatile unsigned int current_cfg = *CFG;
    volatile unsigned int change = function & 0xF; // Extra check to guarantee a valid number will be used for comparisond
    change <<= (gp.pin_index * 4); // Set-up the change in relation to the position in the binary sequence

    // Update the configuration
    *CFG = (current_cfg & ~(0xF << (gp.pin_index * 4))) | change; // make the substitution with the new added value
    }
    return; 
}



  
unsigned int gpio_get_function(gpio_id_t pin) {
  if(gpio_id_is_valid(pin)){  // only use valid pins
  gpio_pin_t gp = get_group_and_index(pin);
    volatile unsigned int *cfg_base = get_cfg(gp.group);
    volatile unsigned int *CFG;
    // Adjust cfg_base based on the pin index to get the correct configuration location
    if (gp.pin_index >= 0 && gp.pin_index < 8) {
        CFG = cfg_base;
    } else if (gp.pin_index >= 8 && gp.pin_index < 16) {
        CFG = cfg_base + 1;
    } else if (gp.pin_index >= 16 && gp.pin_index < 24) {
        CFG = cfg_base + 2;
    } else {
        return GPIO_INVALID_REQUEST; // early return if pin index is out of range
    }

    // Cast cfg_base to an unsigned int pointer
    volatile unsigned int current_cfg = *CFG;

    volatile unsigned int reference_comparison = 0b1111 << (gp.pin_index * 4); // set up the mask to get the correct value
    volatile unsigned int function = (current_cfg & reference_comparison) >> (gp.pin_index * 4); // use the mask to get the wanted function value
    return function; 
     }else{
       return GPIO_INVALID_REQUEST; // return if the pin was invalid
     }
}





void gpio_write(gpio_id_t pin, int value) {
    if (gpio_id_is_valid(pin)) {  // only proceed with valid pins
    gpio_pin_t gp = get_group_and_index(pin);
    volatile unsigned int *DATA = get_data_reg(gp.group);
    
    volatile unsigned int current_data = *DATA;
    // Ensure correct C convention of bits
    volatile unsigned int change  = 0x1;
    if (value == 0){
      change = 0x0; 
    }
    change <<= (gp.pin_index); //  shift the change to create a mask at the right position 

    // Update the configuration
    *DATA = (current_data & ~(0x1 << (gp.pin_index))) | change; // use the mask to change data
}
return;

}

int gpio_read(gpio_id_t pin) {
  if (gpio_id_is_valid(pin)) { // only proceed with valid pins
        gpio_pin_t gp = get_group_and_index(pin);
        volatile unsigned int *DATA = get_data_reg(gp.group);
        volatile unsigned int current_data = *DATA;
      // Create a mask for comparing and retrieving the correct value
       volatile unsigned int reference_comparison = 0b1 << (gp.pin_index);
        // Extract the relevant bits by using the mask 
        volatile unsigned int value = (current_data & reference_comparison) >> (gp.pin_index); // use mask to get data
        return value;
    } else {
        return GPIO_INVALID_REQUEST; //return in case of invalid pins
    }
}


