#include "gpio.h"
#include "pwm.h"
#include "timer.h"
#include "i2c.h"
#include "accel.h"

#include "keyboard.h"
#include "uart.h"
#include "printf.h"

#define MIN_ACC 500
#define MAX_ACC 900
#define MAX_PWM 2500
#define MIN_PWM 1800
#define STOP_PWM 1000
#define BASE_PWM 2300
#define MOVEMENT_OFFSET 200
#define WANTED_HEIGHT 0.5 // Desired height in meters

// Enumeration for drone states
typedef enum {
    TAKE_OFF = 0,
    STABILIZE = 1,
    LANDING = 2,
    ELEVATION = 3
} DroneState;

float height = 0;
float velocity = 0; // Vertical velocity
float acceleration = 0; // Acceleration
float previous_error = 0;
float integral = 0;

// PID controller parameters
float Kp = 1.0; // Proportional gain
float Ki = 0.5; // Integral gain
float Kd = 0.1; // Derivative gain

// Function to calculate height based on acceleration
float calculate_height(float prev_height, float acceleration, int delta_time_ms) {
    float delta_time_s = delta_time_ms / 1000.0;
    float new_velocity = velocity + acceleration * delta_time_s;
    velocity = new_velocity;
    return prev_height + new_velocity * delta_time_s;
}

// PID controller for altitude control
float pid_control(float target, float current, float dt) {
    float error = target - current;
    integral += error * dt;
    float derivative = (error - previous_error) / dt;
    previous_error = error;
    return Kp * error + Ki * integral + Kd * derivative;
}

// Function to perform sensor fusion using accelerometer and gyroscope
void sensor_fusion(imu_data_t *data) {
    float gyro_z_rate = data->gyro.z * (3.14159265 / 180.0); // Convert degrees/sec to rad/sec
    float dt = 0.01; // Assume 10ms loop time for simplicity
    float alpha = 0.98; // Complementary filter constant (tune this value)

    // Integrate gyroscope to get tilt angle
    static float angle = 0;
    angle += gyro_z_rate * dt; // Integrate to get tilt

    // Fuse accelerometer data with the tilt angle
    data->accel.x = (alpha * angle) + ((1 - alpha) * data->accel.x);
    data->accel.y = (alpha * angle) + ((1 - alpha) * data->accel.y);
}

void autom() {
    gpio_id_t pin_esc_1 = GPIO_PB12;
    pwm_channel_id_t ch_esc1 = PWM0;
    gpio_id_t pin_esc_2 = GPIO_PB11;
    pwm_channel_id_t ch_esc2 = PWM2;
    gpio_id_t pin_esc_3 = GPIO_PB0;
    pwm_channel_id_t ch_esc3 = PWM3;
    gpio_id_t pin_esc_4 = GPIO_PB1;
    pwm_channel_id_t ch_esc4 = PWM4;

    pwm_init();

    int freq = 50; // 50 Hz
    int period_us = 1000 * 1000 / freq;
    pwm_config_channel(ch_esc1, pin_esc_1, freq, false);
    pwm_config_channel(ch_esc2, pin_esc_2, freq, false);
    pwm_config_channel(ch_esc3, pin_esc_3, freq, false);
    pwm_config_channel(ch_esc4, pin_esc_4, freq, false);

    DroneState current_state = TAKE_OFF;

    offsets();
    imu_data_t data = update(); // Update function now returns imu_data_t

    while (1) {
        printf("Current Height: %f m\n", height);
        printf("Current Velocity: %f m/s\n", velocity);
        printf("Current Acceleration: %d m/s^2\n", data.accel.z);
        printf("Current State: %d\n", current_state);

        sensor_fusion(&data);

        float pwm_adjustment = 0;
        switch (current_state) {
            case TAKE_OFF:
                if (data.accel.z <= MIN_ACC) {
                    pwm_set_duty(ch_esc1, STOP_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, STOP_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, STOP_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, STOP_PWM * 100 / period_us);
                    timer_delay_ms(500);
                    pwm_set_duty(ch_esc1, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, MAX_PWM * 100 / period_us);
                    timer_delay_ms(5000);
                    height = calculate_height(height, data.accel.z, 10000);
                    current_state = STABILIZE;
                } else {
                    height = calculate_height(height, data.accel.z, 10000);
                    timer_delay_ms(5000);
                }
                break;

            case STABILIZE:
                float control_signal = pid_control(WANTED_HEIGHT, height, 0.01);
                pwm_adjustment = control_signal * 100 / period_us;

                pwm_set_duty(ch_esc1, BASE_PWM + pwm_adjustment);
                pwm_set_duty(ch_esc2, BASE_PWM - pwm_adjustment);
                pwm_set_duty(ch_esc3, BASE_PWM + pwm_adjustment);
                pwm_set_duty(ch_esc4, BASE_PWM - pwm_adjustment);

                char ch = keyboard_read_next();
                if (ch == PS2_KEY_ARROW_UP) {
                    current_state = ELEVATION;
                }
                if (ch == PS2_KEY_ARROW_DOWN) {
                    current_state = LANDING;
                }
                if (ch == PS2_KEY_ARROW_RIGHT) {
                    pwm_set_duty(ch_esc1, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc2, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc3, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc4, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                }
                if (ch == PS2_KEY_ARROW_LEFT) {
                    pwm_set_duty(ch_esc1, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc2, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc3, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc4, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                }
                break;

            case LANDING:
                if (data.accel.z >= MIN_ACC) {
                    pwm_set_duty(ch_esc1, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, MAX_PWM * 100 / period_us);
                    timer_delay_ms(1000);
                    height = calculate_height(height, data.accel.z, 10000);
                    if (height <= 0.2) {
                        pwm_set_duty(ch_esc1, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc2, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc3, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc4, STOP_PWM * 100 / period_us);
                    }
                }
                break;

            case ELEVATION:
                if (data.accel.z <= MIN_ACC) {
                    pwm_set_duty(ch_esc1, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, MAX_PWM * 100 / period_us);
                    timer_delay_ms(10000);
                    height = calculate_height(height, data.accel.z, 10000);
                    current_state = STABILIZE;
                } else {
                    timer_delay_ms(10000);
                    height = calculate_height(height, data.accel.z, 10000);
                    current_state = STABILIZE;
                }
                break;

            default:
                // Handle unexpected states
                break;
        }
    }
}

void controlled() {
    gpio_id_t pin_esc_1 = GPIO_PB12;
    pwm_channel_id_t ch_esc1 = PWM0;
    gpio_id_t pin_esc_2 = GPIO_PB11;
    pwm_channel_id_t ch_esc2 = PWM2;
    gpio_id_t pin_esc_3 = GPIO_PB0;
    pwm_channel_id_t ch_esc3 = PWM3;
    gpio_id_t pin_esc_4 = GPIO_PB1;
    pwm_channel_id_t ch_esc4 = PWM4;

    pwm_init();

    int freq = 50; // 50 Hz
    int period_us = 1000 * 1000 / freq;
    pwm_config_channel(ch_esc1, pin_esc_1, freq, false);
    pwm_config_channel(ch_esc2, pin_esc_2, freq, false);
    pwm_config_channel(ch_esc3, pin_esc_3, freq, false);
    pwm_config_channel(ch_esc4, pin_esc_4, freq, false);

    DroneState current_state = STABILIZE;

    offsets();
    imu_data_t data = update();

    while (1) {
        printf("Current Height: %.2f m\n", height);
        printf("Current State: %d\n", current_state);

        sensor_fusion(&data);

        float pwm_adjustment = 0;
        switch (current_state) {
            case STABILIZE:
                float control_signal = pid_control(WANTED_HEIGHT, height, 0.01);
                pwm_adjustment = control_signal * 100 / period_us;

                pwm_set_duty(ch_esc1, BASE_PWM + pwm_adjustment);
                pwm_set_duty(ch_esc2, BASE_PWM - pwm_adjustment);
                pwm_set_duty(ch_esc3, BASE_PWM + pwm_adjustment);
                pwm_set_duty(ch_esc4, BASE_PWM - pwm_adjustment);

                char ch = keyboard_read_next();
                if (ch == PS2_KEY_ARROW_UP) {
                    current_state = ELEVATION;
                }
                if (ch == PS2_KEY_ARROW_DOWN) {
                    current_state = LANDING;
                }
                if (ch == PS2_KEY_ARROW_RIGHT) {
                    pwm_set_duty(ch_esc1, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc2, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc3, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc4, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                }
                if (ch == PS2_KEY_ARROW_LEFT) {
                    pwm_set_duty(ch_esc1, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc2, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc3, (BASE_PWM - MOVEMENT_OFFSET) * 100 / period_us);
                    pwm_set_duty(ch_esc4, (BASE_PWM + MOVEMENT_OFFSET) * 100 / period_us);
                }
                break;

            case LANDING:
                if (data.accel.z >= MIN_ACC) {
                    pwm_set_duty(ch_esc1, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, MAX_PWM * 100 / period_us);
                    timer_delay_ms(1000);
                    height = calculate_height(height, data.accel.z, 10000);
                    if (height <= 0.2) {
                        pwm_set_duty(ch_esc1, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc2, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc3, STOP_PWM * 100 / period_us);
                        pwm_set_duty(ch_esc4, STOP_PWM * 100 / period_us);
                    }
                }
                break;

            case ELEVATION:
                if (data.accel.z <= MIN_ACC) {
                    pwm_set_duty(ch_esc1, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc2, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc3, MAX_PWM * 100 / period_us);
                    pwm_set_duty(ch_esc4, MAX_PWM * 100 / period_us);
                    timer_delay_ms(10000);
                    height = calculate_height(height, data.accel.z, 10000);
                    current_state = STABILIZE;
                } else {
                    timer_delay_ms(10000);
                    height = calculate_height(height, data.accel.z, 10000);
                    current_state = STABILIZE;
                }
                break;

            default:
                // Handle unexpected states
                break;
        }
    }
}

void main(void){
    gpio_init();
    timer_init();
    uart_init(); 
    printf("\nStarting main() in %s\n", __FILE__);
    interrupts_init();
    autom(); 
}