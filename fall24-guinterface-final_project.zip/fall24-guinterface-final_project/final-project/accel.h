/*
 * Gy-521 3-axis accelerometer+gyroscope i2c sensor
 * Sample code below shows raw accel readings, no calibration/correction
 *
 * https://componentslibrary.com/gy-521-datasheet.html
 * https://protosupplies.com/product/mpu-6050-gy-521-3-axis-accel-gryo-sensor-module/
 */

#ifndef ACCEL_H__
#define ACCEL_H__

#include "assert.h"
#include "i2c.h"
#include "printf.h"
#include "timer.h"
#include "uart.h"

typedef struct {
    short x, y, z; // expressed in mg
} axes_t;

typedef struct {
    axes_t accel;  // Accelerometer readings
    axes_t gyro;   // Gyroscope readings
    float temp;    // Temperature reading in degrees Celsius
} imu_data_t;

static i2c_device_t *gy521_init(void);

short extract_reading(uint8_t *bytes);

// void gy521_read(i2c_device_t *dev, axes_t *p);

void offsets(void);

imu_data_t update(void);



#endif