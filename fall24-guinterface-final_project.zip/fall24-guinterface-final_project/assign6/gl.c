/* File: gl.c
 * ----------
 Intermetiate step between console and fb
 */

#include "strings.h"
#include "gl.h"
#include "font.h"
#include "printf.h"


void gl_init(int width, int height, gl_mode_t mode) {
    fb_init(width, height, mode);
}

int gl_get_width(void) {
    return fb_get_width();
}

int gl_get_height(void) {
    return fb_get_height();
}

color_t gl_color(uint8_t r, uint8_t g, uint8_t b) {
    return ((0xff << 24)|(r<<16)|(g<<8)|b);
}

void gl_swap_buffer(void) {
   fb_swap_buffer(); 
}


void gl_clear(color_t c) {
    int width = fb_get_width();
    int height = fb_get_height();
    unsigned int (*im)[width] = fb_get_draw_buffer();
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            im[y][x] = c;
        }
    }
}
void gl_clear_1(color_t c) {
  int width = fb_get_width();
  int height = fb_get_height();
  int depth = 4; 
  uint8_t *im = fb_get_draw_buffer();
    int total_bytes = width * height * depth;
//     write each byte in the framebuffer
    for (int i = 0; i < total_bytes; i++) {
        *im++ = c;
   
   }
  
}

void gl_draw_pixel(int x, int y, color_t c) {
  unsigned int per_row = fb_get_width();
  unsigned int (*im)[per_row] = fb_get_draw_buffer();
  if(y< fb_get_height() && x < fb_get_width() && x>=0 && y >=0){
    im[y][x] = c;
  }
}


void gl_clear_(color_t c) {
 unsigned int per_row = fb_get_width();
 unsigned int (*im)[per_row] = fb_get_draw_buffer();
 for (int i = 0; i < fb_get_width(); i++) {
   for (int j = 0; j < fb_get_height(); j++) {
   gl_draw_pixel(i, j, c); 
   }
   }
}

color_t gl_read_pixel(int x, int y) {
  unsigned int per_row = fb_get_width();
  unsigned int (*im)[per_row] = fb_get_draw_buffer();
  if(y< fb_get_height() && x < fb_get_width() && x>=0 && y >=0){
    return im[y][x];
  }
  return 0;
}

void gl_draw_rect(int x, int y, int w, int h, color_t c) {

  for(int i = x; i < x+w; i++){
      for(int j = y; j <y+h; j++){
       gl_draw_pixel(i, j, c);
      }
    }

}

void gl_draw_char(int x, int y, char ch, color_t c) {
  int font_height = font_get_glyph_height(); 
  int font_width = font_get_glyph_width(); 
  unsigned int per_row = fb_get_width();
  uint8_t buf[font_get_glyph_size()]; // set the buf where the image will be drawn to be at the poistion [y]
  if(!(font_get_glyph(ch, buf, sizeof(buf)))){
   return; 
  }
  void *ptr = buf;
//  printf("%c", ch); 
//  unsigned int (*og)[font_get_glyph_width()] = &buf;
  for (int j = 0; j< font_height; j++) {
    for (int i = 0; i < font_width; i++) {  
      if(
          buf[j*font_width+i] == 0xff
         // og[j][i] == 0xff
          
          ){
        gl_draw_pixel(x+i, y+j, c);
//        printf("#"); 
      }else{
      }
    }
  }
}

void gl_draw_string(int x, int y, const char* str, color_t c) {
    for(int i = 0; i< strlen(str); i++){
      gl_draw_char(x +i*font_get_glyph_width(), y, str[i], c); 
    }
}

int gl_get_char_height(void) {

    return font_get_glyph_height();
}

int gl_get_char_width(void) {
    return font_get_glyph_width();
}


void gl_draw_line(int x1, int y1, int x2, int y2, color_t c){
  
  int dx = x2-x1;
  int dy = y2-y1; 
  //printf("df: x/ %d y/ %d\n", dx, dy );
  float ratio = (float) dy/dx;
  //printf("df (main): / %f \n", ratio );  
   
  int k = x2>x1? 1 :-1;
  if (dx == 0) {
    int k2 = (y2 > y1) ? 1 : -1;
    for (int y = y1; y != y2 + k2; y += k2) {
        gl_draw_pixel(x1, y, c);
    }
    return;
   }
  if (dy == 0) {
    int k3 = (x2 > x1) ? 1 : -1;
    for (int x = x1; x != x2 + k3; x += k3) {
        gl_draw_pixel(x, y1, c);
    }
    return;
   }

  int j = y1;
  float follow_j = (float) y1; 
  for (int i = x1; i != x2; i+= k){
    follow_j += (float) ratio*k; 
    j = (int) follow_j; 
    //printf("follow j: / %f \n", follow_j ); 
      gl_draw_pixel(i, j,  c);
      //printf("line: x/ %d y/ %d\n", i, j );
  }
    
}

void draw_vert_line(int x,int  y1,int  y2, color_t c){
  int k = y2>y1? 1 :-1;
  for (int i = y1; i!=y2; i+=k){
     printf("(%d,%d),\n", x, i );
    gl_draw_pixel(x, i,  c);
  }
  gl_draw_pixel(x, y2, c);
  gl_draw_pixel(x, y1, c);
}

void gl_save_line(int x1,int  y1,int  x2, int y2,  int *col){
 // printf("SAVE LINE \n");
  int dx = x2-x1;
  int dy = y2-y1;
  float ratio = (float) dy/dx;
  int k = x2>x1? 1 :-1;
  int j = y1;
  int count = 0;
  float follow_j = (float) y1;
  for (int i = x1; i != x2; i+= k){
    follow_j += (float) ratio*k;
    j = (int) follow_j;
    col[i] = j;

   // printf("The list is: %d, %d \n", i, j);
}
col[x2] = y2; 
col[x1] = y1; 
}
void gl_draw_triangle(int x1, int y1, int x2, int y2, int x3, int y3, color_t c){
  int ymax = 0;
  int xmax = 0;
  int xright = 0;
  int yright = 0; 
  int xleft = 0;
  int yleft  = 0; 
  if(x1 >x2 && x1 > x3){
    ymax = y1;
    xmax = x1;
    if(x2>x3){
      xright = x2; 
      yright = y2; 
      
      xleft = x3; 
      yleft = y3; 
    }else{
      xright = x3;
      yright = y3;

      xleft = x2;
      yleft = y2;

    }
  } else if(x2>x3){
    ymax = y2;
    xmax = x2;

    if(x1>x3){
      xright = x1;
      yright = y1; 

      xleft = x3;
      yleft = y3;
    }else{
      xright = x3;
      yright = y3;

      xleft = x1;
      yleft = y1;
    }
  }else{
    ymax = y3; 
    xmax = x3; 
    if(x2>x1){
      xright = x2;
      yright = y2;

      xleft = x1;
      yleft = y1;
    }else{
      xright = x1;
      yright = y1;

      xleft = x2;
      yleft = y2;
    }
  }
//  printf("MAX: x/ %d y/ %d\n", xmax, ymax );
   gl_draw_line(x1, y1, x2,y2,c);
   gl_draw_line(x1, y1, x3,y3,c);
   gl_draw_line(x2, y2, x3,y3,c);

   int colright[800];
   int colleft[800]; 
   int colbottom[800];
  gl_save_line(xmax, ymax, xright, yright,  colright );
  gl_save_line(xmax, ymax, xleft, yleft,  colleft );
 gl_save_line(xright, yright, xleft, yleft,  colbottom );
//  printf("NOW PRINTING THE TRIANGLE! \n"); 
 // printf("The list is: %d, %d, %d\n", xmax, xright, xleft); 
  for(int i = xright; i<=xmax; i++){
   int maxr = colright[i]; 
   int maxl = colleft[i]; 
   draw_vert_line(i, maxr,  maxl,c);
 }
//  printf("NOW PRINTING THE FINAL PART! \n");
 for(int i = xleft; i<= xright; i++){
   int maxr = colleft[i]; 
   int maxb = colbottom[i];
   draw_vert_line(i,maxr,  maxb,c);
 }
 
}
