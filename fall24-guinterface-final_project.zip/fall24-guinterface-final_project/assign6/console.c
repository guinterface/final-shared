/* File: console.c
 *
 * ---------------
 User interface that uses gl.c to manipulate buffer visually
 */
#include "console.h"
#include "gl.h"
#include "malloc.h"
#include "strings.h"
#include "printf.h"
#include "font.h"
// module-level variables, you may add/change this struct as you see fit!
static struct {
    color_t bg_color, fg_color;
    int line_height;
    char *text; 
    int max_x; 
    int max_y; 
    int x;
    int y; 
    int exceeding; 
} module;

void console_init(int nrows, int ncols, color_t foreground, color_t background) {
    // Please add this amount of vertical space between console rows
    const static int LINE_SPACING = 5;

    module.line_height = gl_get_char_height() + LINE_SPACING;
    module.fg_color = foreground;
    module.bg_color = background;
    int ysize = nrows*module.line_height;
    int xsize = ncols*font_get_glyph_width(); 
    gl_init(xsize, ysize, FB_DOUBLEBUFFER);
    char *text = malloc(10*((ncols+1)*nrows));

    module.text = text; 
    memset(module.text, '\0', 10*(nrows*(ncols+1)));
    module.x = 0;
    module.y = 0; 
    module.max_x = ncols;
    module.max_y = nrows;
    module.exceeding = 0;
    gl_clear(module.bg_color);
    gl_swap_buffer(); 
    gl_clear(module.bg_color);
}

void console_clear(void) {
  free(module.text); 
   char *text = malloc(10 * (module.max_y *( module.max_x + 1) ));
module.text = text;
memset(module.text, '\0', 10 * (module.max_y * (module.max_x + 1) ));
module.x = 0;
module.y = 0;
gl_clear(module.bg_color);
}

void console_remove_text(void) {
   gl_clear(module.bg_color);
   gl_swap_buffer();
   gl_clear(module.bg_color);
}

void console_clear_in_script(void) {
    char *text = malloc(2 * (module.max_y * (module.max_x + 1)));
    module.text = text;
    memset(module.text, '\0', 2 * (module.max_y * (module.max_x + 1)));
    module.x = 0;
    module.y = 0;
    gl_clear(module.bg_color);
    gl_swap_buffer();
    gl_clear(module.bg_color);
}

void write_text(void){
  for (int j = 0; j < module.max_y; j++) {
    gl_draw_string(0, j * module.line_height, (void*)((char*)module.text + (module.max_x + 1) * j), module.fg_color);
}
 gl_swap_buffer();
    for (int j = 0; j < module.max_y; j++) {
    gl_draw_string(0, j * module.line_height, (void*)((char*)module.text + (module.max_x + 1) * j), module.fg_color);
}
}

int is_final_end(void){
  if(module.exceeding>=9*(module.max_y)-1){
    return 1;
  }
  return 0;
}
int is_init(void){
  if(module.x <=0 && module.y <=0){
    return 1;
  }
  return 0; 
}
int is_end(void){
  if(module.x >= module.max_x && module.y >= module.max_y){
    
    return 1;
  }
  return 0;
}

void exceed(void){
module.y--; 
console_remove_text();  
module.text = (char*)((char*)module.text + module.max_x + 1);
//printf("Exceeding string: %s", (char*)module.text); 
module.exceeding++;

}

void return_delete(){
  module.y--;
  module.x = strlen((char*)((char*)module.text+module.y*(module.max_x+1)))-1;
  if(module.x<0){
    module.x = 0;
    module.y --;
  }
  module.text[module.y*(module.max_x+1)+ module.x] = '\0';  
  module.text = (char*)((char*)module.text - module.max_x - 1);
  module.y++; 
}
int is_special(char ch){
  if(ch == '\b' || ch == '\n' || ch == '\f' || ch == '\0'){
    switch(ch){
    case '\b':
  //    printf("MOD X: %d\n", module.x); 
  //    printf("MOD Y: %d\n", module.y); 
    if(is_init()){
      
    }else if(module.x <=0){
      return_delete(); 
      console_remove_text();
    }else{
      module.x--;
      module.text[module.y*(module.max_x+1) +module.x] = '\0'; 
      console_remove_text();
    }

    break; 
    case '\n':
    if(module.y>=module.max_y-1){
     exceed(); 
    }
    module.x = 0; 
    module.y++; 
    //printf("exceed MOD X: %d\n", module.x);
    //printf("exceed MOD Y: %d\n", module.y);    
    break;
    case '\f':
    console_clear_in_script(); 
    break; 
    }
    return 1; 
  }
  return 0; 
}
int process_char(char ch) {
//    printf("char: %c", ch);
     if(is_final_end()){
       return 0; 
     }
     if(is_special(ch)){
      return 0; 
    }else if (is_end()){
      exceed(); 
    }
    if(module.x >= module.max_x){
    //  printf("We are current at: %d\n", module.x);
  //    printf("the font is: %d\n", font_get_glyph_width()); 
//      printf("Limit: %d\n", module.max_x*font_get_glyph_width()); 
      module.text[module.y*(module.max_x+1) + module.x] = '\0';
      module.x = 0; 
      module.y++;
      module.text[module.y*(module.max_x+1) +module.x] = ch; 
      module.x++; 
    }else{
      module.text[module.y*(module.max_x+1) +module.x] = ch; 
      module.x++; 
    }
     return 1;
  }
#define MAX_STR 200
int console_printf(const char *format, ...) {
  va_list args;
  va_start(args, format);
      char* buf = malloc(MAX_STR);
      vsnprintf(buf, MAX_STR, format,args);
      //printf("BUFFER: %s,    \n", buf);
      if(buf!=NULL){
      for(int i = 0; i <strlen(buf); i++){
        process_char(buf[i]);
       }
        write_text(); 
      }
  

	return 0;
}


