The only references I used for the extension were the ones provided on the guidelines - 
https://en.wikipedia.org/wiki/Line_drawing_algorithm and https://gabrielgambetta.com/computer-graphics-from-scratch/07-filled-triangles.html#drawing-filled-triangles. 
The math I used was not complicated, only very methodological, replicating especially the strategy of the second link.
Specifically, the strategy I used was to draw the lines with a constant update on x (abscissa axis)
     so that there would be no missing points on this axis. This allowed me to create an array of the y values, 
     which was guaranteed to give us proper values when iterating over the x index values. Hence, I inverted
     the diagram on the second link, and oganized the three vertix points of the triangle to draw a vertical line
     from the most horizontally right located point to the intermediate one, and from this middle to the most left located. 


The line itself is much simpler; whenever our derivatives are not 0, simply update x to x+1 and add y to the derivate. 
The algorithm also draws vertical or horizontal lines in the few edge cases. 
