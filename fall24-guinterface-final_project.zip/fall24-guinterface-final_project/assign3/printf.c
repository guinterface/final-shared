/* File: printf.c
 * --------------
 * Implementation of functions 'vsnprintf', 'snprintf', 'printf' and their auxiliars, done through iterative checking of chars in the received string.
 */
#include "printf.h"
#include <stdarg.h>
#include <stdint.h>
#include "strings.h"
#include <uart.h>

/* Prototypes for internal helpers.
 * Typically we would qualify these functions as static (private to module)
 * but in order to call them from the test program, must declare externally
 */
void num_to_string(unsigned long num, int base, char *outstr);
const char *hex_string(unsigned long val);
const char *decimal_string(long val);

// max number of digits in long + space for negative sign and null-terminator
#define MAX_DIGITS 100


/* Convenience functions `hex_string` and `decimal_string` are provided
 * to you.  You should use the functions as-is, do not change the code!
 *
 * A key implementation detail to note is these functions declare
 * a buffer to hold the output string and return the address of buffer
 * to the caller. If that buffer memory were located on stack, it would be
 * incorrect to use pointer after function exit because local variables
 * are deallocated. To ensure the buffer memory is accessible after
 * the function exists, the declaration is qualified `static`. Memory
 * for a static variable is not stored on stack, but instead in the global data
 * section, which exists outside of any function call. Additionally static
 * makes it so there is a single copy of the variable, which is shared by all
 * calls to the function. Each time you call the function, it overwrites/reuses
 * the same variable/memory.
 *
 * Adding static qualifier to a variable declared inside a function is a
 * highly atypical practice and appropriate only in very specific situations.
 * You will likely never need to do this yourself.
 * Come talk to us if you want to know more!
 */

const char *hex_string(unsigned long val) {
    // static buffer to allow use after function returns (see note above)
    static char buf[MAX_DIGITS];
    num_to_string(val, 16, buf); // num_to_string does the hard work
    return buf;
}

const char *decimal_string(long val) {
    // static buffer to allow use after function returns (see note above)
    static char buf[MAX_DIGITS];
    if (val < 0) {
        buf[0] = '-';   // add negative sign in front first
        num_to_string(-val, 10, buf + 1); // pass positive val as arg, start writing at buf + 1
    } else {
        num_to_string(val, 10, buf);
    }
    return buf;
}

void num_to_string(unsigned long num, int base, char *outstr) {
  int i = 0;
  char buf[65];
  //Save orginally on reverse order
  do {
        int auxiliar = num%base; 
        if(auxiliar <= 9){ //decimal 
        buf[i] = '0' + auxiliar;
        }else{ //hex
          buf[i] = 'a' + auxiliar - 10;
        }
        num = num/base; 
        i++;
    } while(num>0);
  i--;
  int j = 0; 
 // Depending on the context, we could also have: (though not applicable for the project) 
//  if(base == 16){
//    j+=2;
//    outstr[0] = '0';
 //   outstr[1] = 'x'; 
//  }

  //Invert order for finished result
  for (int k = 0; k<=i; k++){
    outstr[k+j] = buf[i-k];
  }
  outstr[i+1+j] = '\0'; 
}

#define BASE_SIZE 100

void *add_padding(const char *base,  int padding_length, char *output) {
    int greater = padding_length > strlen(base) ? padding_length : strlen(base);
    int base_length = strlen(base);
    int size = padding_length - base_length;
    // In case there is no need to add more space
    if (size <= 0) {
        memcpy(output, base, base_length);
        output[base_length] = '\0';
        return output;
    }
    //Otherwise, append the corresponding size
    char *padding[padding_length+1]; 
    memset(padding, ' ', padding_length); 
    memcpy(output, padding, size);
    output[size] = '\0';
    strlcat(output, base, greater + 1);

    return output;

}

void *add_padding_hex(const char *base, int padding_length, char *output) {
      int greater = padding_length > strlen(base) ? padding_length : strlen(base);
      int base_length = strlen(base);
      int size = padding_length - base_length;

      if (size <= 0) {
       memcpy(output, base, base_length);
      output[base_length] = '\0';
      return output;
      }
      char padding[padding_length + 1];
      memset(padding, '0', padding_length);

      memcpy(output, padding, size);
      output[size] = '\0';
      strlcat(output, base, greater + 1);

      return output;
}

static const char *reg_names[32] = {
    "zero", "ra", "sp", "gp", "tp", "t0", "t1", "t2",
    "s0/fp", "s1", "a0", "a1", "a2", "a3", "a4", "a5",
    "a6", "a7", "s2", "s3", "s4", "s5", "s6", "s7",
    "s8", "s9", "s10", "s11", "t3", "t4", "t5", "t6"
};


#define MAX_LENGTH 64

char *disassembler(unsigned int opcode,unsigned int auxiliar) {
   // const char* opcode_str_const = (const char*) opcode_str;
   // const char* auxiliar_str_const = (const char*) auxiliar_str;
   // int opcode = strtonum(opcode_str_const, opcode_str_const + strlen(opcode_str));
   // int auxiliar = strtonum(auxiliar_str_const, auxiliar_str_const + strlen(auxiliar_str));
    static char base[MAX_LENGTH];
    base[0] = '\0'; // Initialize to an empty string

    if (opcode == 0b0110011) {
        static const char *f3_0_names[32] = {"add", "sll", "slt", "sltu", "xor", "srl",  "or", "and", "slli"};
        static const char *f3_1_names[32] = {"sub", "sra"};

        unsigned int reg_d = (auxiliar >> 7) & 0x1F;
        unsigned int funct3 = (auxiliar >> 12) & 0x7;
        unsigned int reg_s1 = (auxiliar >> 15) & 0x1F;
        unsigned int reg_s2 = (auxiliar >> 20) & 0x1F;
        unsigned int funct7 = (auxiliar >> 25) & 0x7F;

        if (funct7 == 0b000) {
            strlcat(base, f3_0_names[funct3], sizeof(base));
        } else if (funct7 == 0b001) {
            strlcat(base, f3_1_names[funct3 != 0], sizeof(base));
        }

        snprintf(base + strlen(base), MAX_LENGTH - strlen(base), " %s, %s, %s", reg_names[reg_d], reg_names[reg_s1], reg_names[reg_s2]);

    } else if (opcode == 0b0010011) {
        static const char *f3_0_names[32] = {"addi", "slti", "sltiu", "xori", "ori", "andi"};

        unsigned int reg_d = (auxiliar >> 7) & 0x1F;
        unsigned int funct3 = (auxiliar >> 12) & 0x7;
        unsigned int reg_s1 = (auxiliar >> 15) & 0x1F;
        unsigned int immediate = (auxiliar >> 20) & 0xFFF;

        snprintf(base, MAX_LENGTH, "%s %s, %s, %d", f3_0_names[funct3], reg_names[reg_d], reg_names[reg_s1], immediate);
    } else if (opcode == 0b1100011) {
        static const char *f3_0_names[32] = {"beq", "bne", "blt", "bge", "bltu", "bgeu"};
        unsigned int reg_s1 = (auxiliar >> 15) & 0x1F;
        unsigned int reg_s2 = (auxiliar >> 20) & 0x1F;
        unsigned int funct3 = (auxiliar >> 12) & 0x7;
        unsigned int immediate = ((auxiliar >> 31) & 0x1) << 12 |
                                 ((auxiliar >> 25) & 0x3F) << 5;

        snprintf(base, MAX_LENGTH, "%s %s, %s, %d", f3_0_names[funct3], reg_names[reg_s1], reg_names[reg_s2], immediate);
    } else {
        return (char*) hex_string(auxiliar);
    }

    return base;
}


int vsnprintf(char *buf, size_t bufsize, const char *format, va_list args) {
  int i = 0;
  int count = 0;
  int len;
  if(bufsize >0){
  buf[0] = '\0';
  }
  while (format[i] != '\0') {
    if (format[i] == '%') {
      // Simplest case; just print a '%' sign
        int padding = 0;
        if (format[i + 1] == '%') {
            if (count < bufsize - 1) {
                buf[count] = format[i];
                buf[count + 1] = '\0';
            }
            i+=2;
            count++;
        } else {
            char output[BASE_SIZE];
            char str_to_num[BASE_SIZE];
            int j = 0;
            //Account for padding value input
            while (format[i + 1] >= '0' && format[i + 1] <= '9') {
                str_to_num[j] = format[i + 1];
                i++;
                j++;
            }
            if (j != 0) { //If padding was requested
                str_to_num[j] = '\0';
                padding = strtonum(str_to_num, NULL);
            }
            if (format[i + 1] == 'c') {
                //Char case
                char record[10]; 
                record[0] = (char)va_arg(args, int);
                record[1] = '\0'; 
                add_padding(record, padding, output);
                len = strlen(output);
                // Update counting and iteration value 
                count += len;
                i += 2;
                strlcat(buf, output, bufsize); // save result
            } else if (format[i + 1] == 's') {
                //String case
                char *record = va_arg(args, char*);
                add_padding(record, padding, output);
                len = strlen(output);
                // Update counting and iteration value
                count += len;
                i += 2;
                strlcat(buf, output, bufsize); //save result
            } else if ((format[i + 1] == 'd' || (format[i + 1] == 'l' && format[i + 2] == 'd'))) {
                //Int case
                long auxiliar; 
                if(format[i+1] == 'l'){
                  // We are dealing with a large int 
                  i++;
                   auxiliar = va_arg(args, long);
                   }else{
                   auxiliar = va_arg(args, int);
                   }
                const char *record = decimal_string(auxiliar);
                add_padding(record, padding, output);
                // Update counting and iteration value 
                len = strlen(output);
                count += len;
                i += 2;
                strlcat(buf, output, bufsize); //save result
            } else if ((format[i + 1] == 'x' || (format[i + 1] == 'l' && format[i + 2] == 'x'))) {
                //Hex case
                long auxiliar;
                if(format[i+1] == 'l'){
                //We are dealing with a large hex
                  i++;
                auxiliar = va_arg(args,  unsigned long);
                }else{
                auxiliar = va_arg(args, unsigned int);}
                const char *record = hex_string((unsigned long)auxiliar); 
                add_padding_hex(record, padding, output);
                len = strlen(output);
                // Update counting and iteration value
                count += len;
                i += 2;
                strlcat(buf, output, bufsize); //save result
            } else if (format[i + 1] == 'p' && format[i + 2] == 'I') {
            i++;

           unsigned int *auxiliar = va_arg(args, unsigned int *);
           unsigned int opcode = *auxiliar & 0x7F;
           char *base = disassembler(opcode, *auxiliar);

 
         // num_to_string(auxiliar, 16, record);
           add_padding_hex(base, j != 0 ? padding : 8, output);
           strlcat(base, output, BASE_SIZE);
           len = strlen(base);
           count += len;
           i += 2;
           strlcat(buf, base, bufsize);
            }
            else if (format[i + 1] == 'p') {
             //Pointer case
             char base[MAX_LENGTH];
             //Create an initial base for the hex value of the pointer
             base[0] = '0';
             base[1] = 'x';
             base[2] = '\0';
              unsigned long auxiliar = va_arg(args, unsigned long);
             const char *record = hex_string((unsigned long)auxiliar);  
             add_padding_hex(record, j != 0 ? padding : 8, output);
             //Since we have our base, it is easier to proceed by appending the output to its end
             strlcat(base, output, BASE_SIZE);
             len = strlen(base);
             // Update counting and iteration value
             count += len;
             i += 2;
             strlcat(buf, base, bufsize); //save result
        }


        }
    } else {
      //Proceed with a normal char, not based on received params
        if (count < bufsize - 1 && bufsize > 0) {
            buf[count] = format[i];
            buf[count + 1] = '\0';
        }
        i++;
        count++;
    }
  }
  return count;
}

int snprintf(char *buf, size_t bufsize, const char *format, ...) {
va_list ap;
va_start(ap, format); 
//Use core function with created list
int result =  vsnprintf(buf, bufsize, format, ap);
va_end(ap); 
return result;

}


// ok to assume printf output is never longer that MAX_OUTPUT_LEN
#define MAX_OUTPUT_LEN 1024

int printf(const char *format, ...) {
  char string[MAX_OUTPUT_LEN]; 
  va_list ap;
  va_start(ap, format);
  int result = vsnprintf(string, MAX_OUTPUT_LEN, format, ap);
  //Handing string over
  uart_putstring(string);
  va_end(ap);
  return result;
}


/* From here to end of file is some sample code and suggested approach
 * for those of you doing the disassemble extension. Otherwise, ignore!
 *
 * The struct insn bitfield is declared using exact same layout as bits are organized in
 * the encoded instruction. Accessing struct.field will extract just the bits
 * apportioned to that field. If you look at the assembly the compiler generates
 * to access a bitfield, you will see it simply masks/shifts for you. Neat!
 */
/*
 */ 


struct insn  {
    uint32_t opcode: 7;
    uint32_t reg_d:  5;
    uint32_t funct3: 3;
    uint32_t reg_s1: 5;
    uint32_t reg_s2: 5;
    uint32_t funct7: 7;
};

void sample_use(unsigned int *addr) {
    struct insn in = *(struct insn *)addr;
    printf("opcode is 0x%x, reg_dst is %s\n", in.opcode, reg_names[in.reg_d]);
}


