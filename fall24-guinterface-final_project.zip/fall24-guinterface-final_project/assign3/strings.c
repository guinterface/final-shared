/* File: strings.c
 * ---------------
 * ***** TODO: add your file header comment here *****
 */
#include "strings.h"

void *memcpy(void *dst, const void *src, size_t n) {
    /* Copy contents from src to dst one byte at a time */
    char *d = dst;
    const char *s = src;
    while (n--) {
        *d++ = *s++;
    }
    return dst;
}

void *memset(void *dst, int val, size_t n) {
    char *d = dst;
    while(n--){
      *d++ = val; 
    }
    return NULL;
}

size_t strlen(const char *str) {
    /* Implementation a gift to you from lab3 */
    size_t n = 0;
    while (str[n] != '\0') {
        n++;
    }
    return n;
}

int strcmp(const char *s1, const char *s2) {
    size_t n = 0;
    while (s1[n] != '\0' && s2[n] != '\0') {
    if(s1[n]>s2[n]){
      return 1; 
    }else{
      if(s1[n]<s2[n]){
        return -1; 
      }
    }
    n++;
    }
    if(s1[n] != '\0'){
      return 1;
    }else if(s2[n] != '\0'){
      return -1; 
    }
    return 0;
}

size_t strlcat(char *dst, const char *src, size_t dstsize) {
    size_t dst_len = strlen(dst);
    size_t src_len = strlen(src);

    if (dstsize <= dst_len) {
        return dstsize + src_len;
    }

    size_t available = dstsize - dst_len - 1;
    size_t fill_space = (src_len < available) ? src_len : available;

    memcpy(dst + dst_len, src, fill_space);
    dst[dst_len + fill_space] = '\0';

    return dst_len + src_len;
}


int check_hex(char num) {
    if ((num >= '0' && num <= '9') || 
        (num >= 'A' && num <= 'F') || 
        (num >= 'a' && num <= 'f')) {
        return 1;
    }
    return 0;
}

int check_dec(char num) {
    if ((num >= '0' && num <= '9')){
        return 1;
    }
    return 0;
}



unsigned long strtonum(const char *str, const char **endptr) {
    unsigned long result = 0;
    int i = 0;

    if (str[0] == '0' && str[1] == 'x') {
        i = 2;
        while (str[i] != '\0') {
            if (!check_hex(str[i])) {
                break;
            }
            if (str[i] >= '0' && str[i] <= '9') {
                result = result * 16 + (str[i] - '0');
            } else if (str[i] >= 'A' && str[i] <= 'F') {
                result = result * 16 + (str[i] - 'A' + 10);
            } else if (str[i] >= 'a' && str[i] <= 'f') {
                result = result * 16 + (str[i] - 'a' + 10);
            }
            i++;
        }
    } else {
        while (str[i] != '\0') {
            if (!check_dec(str[i])) {
                break;
            }
            result = result * 10 + (str[i] - '0');
            i++;
        }
    }

    if (endptr) {
        *endptr = &str[i];
    }

    return result;
}
