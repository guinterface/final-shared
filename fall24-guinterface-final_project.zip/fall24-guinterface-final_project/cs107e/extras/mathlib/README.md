Code written by Calvin Xu, CS107e alum

// uses only elementary methods
// guarantees none of speed, precision or accuracy
// I didn't read the specs
// does not handle any errors
// might be educational; definitely not practical
