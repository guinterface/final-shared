Code written by Yifan Yang, CS107e alum

Uses the SPI peripheral on Mango Pi
