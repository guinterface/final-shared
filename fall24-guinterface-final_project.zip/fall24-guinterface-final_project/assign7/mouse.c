/* File: mouse.c
 *
    * 
    *
    * -------------------
   * ***** TODO: add your file header comment here *****
 */

#include "gpio.h"
#include "mouse.h"
#include "ps2.h"
#include "printf.h"

static ps2_device_t *dev;  
void mouse_init(gpio_id_t clock, gpio_id_t data) {
    dev = ps2_new(clock, data); 

    // Send Reset command
    if (!ps2_write(dev, 0xFF)) {
        printf("Failed to send Reset command\n");
        return;
    }

    // Wait for acknowledgment (0xFA) and self-test response (0xAA)
    uint8_t ack = ps2_read(dev);
    if (ack != 0xFA) {
        printf("No acknowledgment for Reset: received %x\n", ack);
        // return;
    }

    uint8_t self_test = ps2_read(dev);
    if (self_test != 0xAA) {
        printf("Self-test failed: received %x\n", self_test);
        // return;
    }

    // Send Enable Data Reporting command
    if (!ps2_write(dev, 0xF4)) {
        printf("Failed to send Enable Data Reporting command\n");
        // return;
    }

    // Wait for acknowledgment (0xFA)
    ack = ps2_read(dev);
    if (ack != 0xFA) {
        printf("No acknowledgment for Enable Data Reporting: received %x\n", ack);
        // return;
    }

    printf("Mouse initialized successfully\n");
}

  mouse_event_t mouse_read_event(void){
 printf("Started"); 
  uint8_t byte1, byte2, byte3; 
  byte1 = ps2_read(dev);   
  printf("Got 1 byte"); 
   byte2 = ps2_read(dev);
   byte3 = ps2_read(dev);
  mouse_event_t mouse; 
   if(!(byte1>>3 & 0b1)){
    mouse.dx = 0;
        mouse.dy = 0;
        mouse.x_overflow = 0;
        mouse.y_overflow = 0;
        mouse.left = 0;
        mouse.right = 0;
        mouse.middle = 0;
        mouse.action = MOUSE_BUTTON_RELEASE;
        return mouse; 
  }
   mouse.dx = (int8_t)(byte2); 
   mouse.dy = (int8_t)(byte3); 
   mouse.x_overflow = (byte1>>6 & 0b1);
   mouse.y_overflow = (byte1>>7 & 0b1);
   mouse.middle = (byte1>>2 & 0b1);  //bit 2
   mouse.right = (byte1>>1 & 0b1);  //bit 1
   mouse.left = (byte1>>0 & 0b1); //bit 0
   if(mouse.middle || mouse.left || mouse.right){
      if(mouse.dx || mouse.dy){
        mouse.action = MOUSE_DRAGGED; 
      }else{
         mouse.action = MOUSE_BUTTON_PRESS; 
      }

   }else{
     if(mouse.dx || mouse.dy ){
       mouse.action = MOUSE_MOVED; 
     }else{
       mouse.action = MOUSE_BUTTON_RELEASE;
     }
   }
   printf("Mouse action: %d \n", mouse.action);
    return mouse; 
  }
