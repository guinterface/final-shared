/* File: ps2_assign7.c
 * 
 *
 * -------------------
 * ***** TODO: add your file header comment here *****
 */

#include "gpio.h"
#include "malloc.h"
#include "ps2.h"
#include "gl.h"
#include "gpio.h"
#include "gpio_extra.h"
#include "gpio_interrupt.h"
#include "interrupts.h"
#include "printf.h"
#include "ringbuffer.h"
#include "uart.h"
#include "timer.h"
#include "keyboard.h"

// A ps2_device is a structure that stores all of the state and information
// needed for a PS2 device. The clock field stores the gpio id for the
// clock pin, and the data field stores the gpio id for the data pin.
// Read ps2_new for example code that sets and uses these fields.
//
// You may extend the ps2_device structure with additional fields as needed.
// A pointer to the current ps2_device is passed into all ps2_ calls.
// Storing state in this structure is preferable to using global variables:
// it allows your driver to support multiple PS2 devices accessed concurrently
// (e.g., a keyboard and a mouse).
//
// This definition fills out the structure declared in ps2.h.
struct ps2_device {
    gpio_id_t clock;
    gpio_id_t data;
    int aux_data; 
    rb_t *rb; 
};
int count = 0;
int scancode = 0; 


// Helper function to verify if the parity bit is correct
int check_parity(int val) {
    int parity = 0;
    for (int i = 1; i < 10; i++) {
        parity ^= (val >> i) & 0b1;
    }
    return parity;
}
void click_handler(void *arg) {
    
    ps2_device_t *dev = (ps2_device_t *)arg;
    gpio_interrupt_clear(dev->clock);


    dev->aux_data = gpio_read(dev->data);
    int bit = dev->aux_data; 
    if ((count == 0) && !((bit & 0b1) == 0)) {
        scancode = 0; 
        count = 0; 
        }

    if((count == 10) && !((bit & 0b1) == 1)){
       scancode = 0; 
        count = 0; 
    }
    scancode += ((1 * sizeof(char)) << (10 - count)) * bit;

    if ((count == 9) && !check_parity(scancode)) {
        scancode = 0; 
        count = 0; 
    }

    if (++count == 11) {
        int result = scancode; 
        scancode = 0; 
        count = 0;
        rb_enqueue(dev->rb, result);
    }
    
}

void config_interrupt(ps2_device_t *dev) {
   // interrupts_init();
    gpio_interrupt_init();
    gpio_interrupt_config(dev->clock, GPIO_INTERRUPT_NEGATIVE_EDGE, false);

    gpio_interrupt_register_handler(dev->clock, click_handler, (void *)dev);
    gpio_interrupt_enable(dev->clock);
    interrupts_global_enable();
}


// Creates a new PS2 device connected to given clock and data pins,
// The gpios are configured as input and set to use internal pull-up
// (PS/2 protocol requires clock/data to be high default)
ps2_device_t *ps2_new(gpio_id_t clock_gpio, gpio_id_t data_gpio) {
    ps2_device_t *dev = malloc(sizeof(*dev));
    dev->rb = rb_new(); 
    dev->clock = clock_gpio;
    gpio_set_input(dev->clock);
    gpio_set_pullup(dev->clock);
  
    dev->data = data_gpio;
    gpio_set_input(dev->data);
    gpio_set_pullup(dev->data);
    return dev;
}




static int is_valid(int val) {
    if ((val & 0b1) == 1 && ((val >> 10) & 0b1) == 0 && check_parity(val)) {
        return 1;
    } else {
        return 0;
    }
}

// Helper function to get the numerical value corresponding to the input Data
uint8_t get_data(int value) {
    int result = 0;
    value = value >> 2;
    value = value & 0b11111111;
    for (int i = 0; i < 8; i++) {
        result <<= 1;
        result += value & 0b1;
        value >>= 1;
    }
    return result;
}





// Read a single PS2 scancode. Always returns a correctly received scancode:
// if an error occurs (e.g., start bit not detected, parity is wrong), the
// function should read another scancode.
uint8_t ps2_read(ps2_device_t *dev) {
    gpio_init();
     int *value;
     int val_ref = 0; 
     value = &val_ref; 
    // printf("\ndev \n"); 
    rb_t *rb = dev->rb;
    gpio_id_t clock = dev->clock;
    gpio_id_t data = dev->data;
    gpio_set_input(clock);
    gpio_set_pullup(clock);
    gpio_set_input(data);
    gpio_set_pullup(data);
    config_interrupt(dev);
    // printf("\n configured \n"); 

 while(!rb_dequeue(rb,value )){

 }
    return get_data(*value);
}

void write_loop(ps2_device_t *dev, int val){
    gpio_write(dev->data, val);
    while(gpio_read(dev->clock) !=1){}
    while(gpio_read(dev->clock) !=0){}
}

bool ps2_write(ps2_device_t *dev, uint8_t command){

  gpio_id_t clock = dev->clock;
  gpio_id_t data = dev->data;
  gpio_set_output(clock);
  gpio_set_output(data);
    
printf("Ponto -2");
  gpio_write(clock, 0);
timer_delay_ms(100);
printf("Ponto -1");
gpio_write(data, 0);
gpio_set_input(clock);  
gpio_set_pullup(clock);
printf("Ponto 0");
  while(gpio_read(clock) !=0){}
 for(int i = 0; i < 8; i++){
   printf("started");
     write_loop(dev, command>>(i) & 0b1); 
 }
 printf("Ponto 1");
   write_loop(dev, check_parity(command)); 
  gpio_set_pullup(data);
  gpio_set_input(data);
  printf("Ponto 2"); 
  while(gpio_read(dev->data) !=0){}
  while(gpio_read(dev->clock) !=0){}

  while (gpio_get_function(data) != GPIO_FN_INPUT || gpio_get_function(clock) != GPIO_FN_INPUT) {}


 // int val = ((command)<<1);
 // printf("val: %d \n", val);
 // val+=1; 
 // printf("val: %d \n", val);

 // val+= check_parity(val)<<9;
  //printf("val: %d \n", val);
  //for(int i = 0; i< 11; i++){
  //  gpio_write(dev->data, val>>(i) & 0b1); 
   // printf("val: %d \n", val>>(i) & 0b1); 
  //}
  //if(ps2_read(dev) != 0xFA){
   // printf("Nope! \n");
  //}; 

  return 1;
 // for (int j = 1; j<8; j++){
   // val += ((command) >> (j))<<(j);
 // }
} 
