#ifndef _GCD_H
#define _GCD_H

int gcd(int a, int b);

#endif