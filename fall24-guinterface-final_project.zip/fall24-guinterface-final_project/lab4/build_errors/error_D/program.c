#include "timer.h"

void main(void) {
    timer_init();

    timer_delay(1);
}
